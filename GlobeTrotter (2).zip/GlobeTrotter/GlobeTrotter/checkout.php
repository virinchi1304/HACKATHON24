<?php
include "dbcon.php";
session_start();
if($_SESSION['NO'] != 1){
  echo "<script type = \"text/javascript\">
              window.location = (\"login.php\")
              </script>";
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Processing</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-aFq/bzH65dt+w6FI2ooMVUpc+21e0SRygnTpmBvdBgSdnuTN7QbdgL+OapgHtvPp" crossorigin="anonymous">
</head>
<body style="background-color:#f8f9fc;">
<div class="text-center">
  <div class="spinner-border" role="status">
  </div>
</div>
<div class="text-center">
<span style="margin-left:10px;">Processing..</span></div>

<?php
      header("refresh:3; url=newhome.php"); 
      require 'PHPMailerAutoload.php';
			require 'credential.php';
				$query = "SELECT Cost_of_Plan FROM planner_details WHERE User_ID = '$_SESSION[ID]'";
				$result = $con->query($query);
				$final = $result->fetch_assoc();
        $query1 = "SELECT Email_ID FROM user_details WHERE User_ID = '$_SESSION[ID]'";
				$result1 = $con->query($query1);
				$final1 = $result1->fetch_assoc();
			$mail = new PHPMailer;                    
			$mail->isSMTP();                                      
			$mail->Host = 'smtp.gmail.com';  
			$mail->SMTPAuth = true;                              
			$mail->Username = EMAIL;                 
			$mail->Password = PASS;                         
			$mail->SMTPSecure = 'tls';                              
			$mail->Port = 587; 
			$mail->SMTPKeepAlive = true;   
			$mail->setFrom(EMAIL, 'GlobeTrotter');
			$mail->addAddress($final1['Email_ID']); 
			$mail->addReplyTo(EMAIL);
			$mail->isHTML(true);                                  
			$mail->Subject = 'GlobeTrotter - Order Details';
			$mail->Body    = "Thank you for placing your order with GlobeTrotter" . "<br>" . "We will make sure to give you a experience of a lifetime". "<br>". "Your final bill amount is". $final['Cost_of_Plan'] . "<br>". "Any queries feel free to contact us";
			if(!$mail->send()) {
			    echo 'Message could not be sent.';
			    echo 'Mailer Error: ' . $mail->ErrorInfo;
			} else {
			    echo "<div class='alert alert-success' role='alert' style='margin-top:6px;' align='center'>
							Mail has been sent!
    					</div>";
			}
?>
</body>
</html>
