<html>
  <?php
  include "dbcon.php";
  session_start();
  if($_SESSION['NO'] != 1){
    echo "<script type = \"text/javascript\">
                window.location = (\"login.php\")
                </script>";
}
  ?>
<head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-aFq/bzH65dt+w6FI2ooMVUpc+21e0SRygnTpmBvdBgSdnuTN7QbdgL+OapgHtvPp" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.min.js" integrity="sha384-VHvPCCyXqtD5DqJeNxl2dtTyhF78xXNXdkwX1CZeRusQfRKp+tA7hAShOK/B/fQ2" crossorigin="anonymous"></script>
    <style>
    </style>
    <title>GlobeTrotter</title>
</head>
<body data-bs-theme="light">
<nav class="navbar navbar-dark bg-dark" style="height:70px;">
            <div class="container-fluid">
            <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST" style="margin-top:10px;">
              <a class="navbar-brand" href="home.php">GlobeTrotter</a>
              <a class="btn btn-secondary" onclick="myFunction()" role="switch" style="margin-left:890px;">Switch Mode</a>
              <button  type="submit" class="btn btn-success" style="margin-left:10px;" name = "planner">Planner</button>
              <?php
              if(isset($_POST['planner'])){
                $id = $_SESSION['ID'];
                $query = "SELECT User_ID from user_details WHERE User_ID = '$id'";
                $result = $con->query($query);
                $num3 = $result->num_rows;
                echo "$num3";
                if($num3 == 0){
                  header('Location: http://' . $_SERVER['HTTP_HOST'] . '/GlobeTrotter/login.php', true, 303);
                  exit();
                  }
                else{
                  header('Location: http://' . $_SERVER['HTTP_HOST'] . '/GlobeTrotter/planner.php', true, 303);
                  exit();
                }
              }
               ?>
              <button  type="submit" class="btn btn-danger" style="margin-left:10px;" name = "logout">Logout</button>
              <?php
                if(isset($_POST['logout'])){
                session_destroy();
                echo "<script type = \"text/javascript\">
                window.location = (\"home.php\")
                </script>";
                }
            ?>
              </form>
            </div>
        </nav>
      <div id="carousel-example-2" class="carousel slide carousel-fade" data-ride="carousel">
        <div class="carousel-inner" role="listbox">
          <div class="carousel-item active">
            <div class="view">
              <img class="d-block w-100" src="assets/2.jpg" width="550px" height="550px"
                alt="First slide">
              <div class="mask rgba-black-light"></div>
            </div>
            <div class="carousel-caption">
              <h3 class="h3-responsive">Traditions</h3>
              <p>Unique. Personal.</p>
            </div>
          </div>
          <div class="carousel-item">
            <div class="view">
              <img class="d-block w-100" src="assets/3.jpg" width="550px" height="550px"
                alt="Second slide">
              <div class="mask rgba-black-strong"></div>
            </div>
            <div class="carousel-caption">
              <h3 class="h3-responsive">Hidden Gems</h3>
              <p>Comfort. Privacy.</p>
            </div>
          </div>
          <div class="carousel-item">
            <div class="view">
              <img class="d-block w-100" src="assets/1.jpg" width="550px" height="550px"
                alt="Third slide">
              <div class="mask rgba-black-slight"></div>
            </div>
            <div class="carousel-caption">
              <h3 class="h3-responsive">Convenient</h3>
              <p>Anytime. Anywhere.</p>
            </div>
          </div>
        </div>
        <a class="carousel-control-prev" href="#carousel-example-2" role="button" data-slide="prev">
          <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        </a>
        <a class="carousel-control-next" href="#carousel-example-2" role="button" data-slide="next">
          <span class="carousel-control-next-icon" aria-hidden="true"></span>
        </a>
      </div>
  <br><br>
  <div class="container-fluid">
    <div class="row">
    <div class="title" style="color: black;">
      <h1><center>About us</center></h1>
    </div>
    </div>
    <div class="row">
    <div class="card justify-content-center text-white bg-secondary" style="margin-left:25px;max-width: 1300px; min-height: 200px;">
                <div class="card-body">
                  <p class="card-text" style="margin-top:10px;">Welcome to our Globe Trotter website dedicated to showcasing the hidden gems of our beautiful city! Our team is made up of passionate travellers who are deeply in love with the city and all its incredible treasures.
    We believe that travel should be an enriching and transformative experience, which is why we are dedicated to promoting unique destinations that are often overlooked by mass tourism. Our website is full of insider information, local recommendations and unique experiences you won't find anywhere else.We are proud of our commitment to responsible and sustainable travel. We work closely with local communities and businesses to ensure that our tours and experiences benefit everyone involved. We also understand that every traveler is unique, which is why we offer itineraries tailored to your interests and preferences. Our team of experts will work with you to create a custom itinerary that fits your schedule and travel style. We guarantee that you will have an unforgettable experience that will last a lifetime.</p>
                  <br>
                </div>
              </div>
  </div>
  </div><br>
  <table class="table table-borderless">
      <section id="cardy">
        <div class="container">
          <div class="title" style="color: black;">
            <h1><center>Reviews</center></h1>
            <h5><center>Our customers have said</center></h5>
          </div><br>
          <div class="row">
            <div class="col-md-4">
              <div class="card text-center text-white bg-secondary" style="max-width: 20rem; min-height: 200px;">
                <div class="card-body">
                  <h4 class="card-title">Absolutely satisfied</h4>
                  <p class="card-text">"The website is a treasure trove of information about offbeat destinations, and the team behind it is extremely helpful and knowledgeable"</p>
                  <br>
                </div>
              </div>
            </div>
            <div class="col-md-4">
              <div class="card text-center bg-secondary text-white" style="max-width: 20rem; min-height: 200px;">
                <div class="card-body">
                  <h4 class="card-title">Amazing!</h4>
                  <p class="card-text">"I felt like I had my own personal travel guide with me the whole time. Thank you for an unforgettable experience! I can't wait to book with them again"</p>
                 <br>
                </div>
              </div>
            </div>
              <div class="col-md-4">
                <div class="card text-center bg-secondary text-white" style="max-width: 20rem; min-height: 200px;">
                  <div class="card-body">
                    <h4 class="card-title">Worth it</h4>
                    <p class="card-text">"They took the time to understand my needs and preferences, and they came up with a customized itinerary that exceeded my expectations"</p>
                   <br>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
</table>  
<br><br>
<div class="container-fluid" style="background-color: #231F20; min-height: 200px; color:white;"><br>
<div class="row">
  <div class="col-md-3" style="margin-top:12%">
© 2023 Void Main. All rights reserved. </div>
<div class="col-md-4">
<div class="d-flex" style="height: 200px;margin-left:75%;">
  <div class="vr"></div>
</div></div>
  <div class="col-md-5">
    <div><h4>Contact Us</h4></div><br>
    Email: Globe.Trotter.Pvt.Ltd@gmail.com<br>
    Instagram: _globe_trotter_official_<br>
    Twitter: @TrotterLtd<br><br>
    <div style="margin-top:9px;"><a href="forum.php">Give us your feedback</a></div>
  </div>
</div>
</div>
</body>
<script>
  function myFunction() {
        var element = document.body;
        element.dataset.bsTheme =
          element.dataset.bsTheme == "light" ? "dark" : "light";
      }
      </script>
</html>
