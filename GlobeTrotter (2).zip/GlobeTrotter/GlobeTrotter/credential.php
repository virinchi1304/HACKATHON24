<?php 
	define('EMAIL', 'Globe.Trotter.Pvt.Ltd@gmail.com'); 
	define('PASS', 'kczgwtxsqxadgdnu'); 
 ?>