<?php
include "dbcon.php";
session_start();
?>
<html>
    <head>
        <title>Login</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-aFq/bzH65dt+w6FI2ooMVUpc+21e0SRygnTpmBvdBgSdnuTN7QbdgL+OapgHtvPp" crossorigin="anonymous">
    </head>
    <body data-bs-theme="light">
    <nav class="navbar navbar-dark bg-dark" style="height:70px;">
            <div class="container-fluid">
              <a class="navbar-brand" href="home.php">GlobeTrotter</a>
              <a class="btn btn-secondary" onclick="myFunction()" role="switch" style="margin-left:1005px;">Switch Mode</a>
              <a href="signup.php" type="button" class="btn btn-success" style="margin-left:10px;">Signup</a>
            </div>
        </nav>
        <div class="card" style="width: 500px;height:420px;margin-left:30%;margin-top:70px;box-shadow: 10px 10px 5px lightgrey;">
            <div class="card-body">
                <form action="<?php echo $_SERVER['PHP_SELF']; ?>"method="POST">
                <h5 class="card-title" align="center" style="font-size:30px">Login Panel</h5>
                <p class="card-text">
                <div style="margin-top:35px;">
                <div style="margin-top:35px;">
                    <label for="username" class="form-label">Username</label>
                    <input type="password" class="form-control" name="username" placeholder="username">
                </div> 
                <div style="margin-top:35px;">
                    <label for="password" class="form-label">Password</label>
                    <input type="password" class="form-control" name="password" placeholder="password">
                </div>  
                <div style="margin-top:35px;">
                    <button type="submit" class="btn btn-outline-primary" style="min-width:465px;" name="login" type="submit" value="login">Login</button>
                </div>
                <div align="center" style="margin-top:35px;">
                    <a href="forgotpwd.php">Forgot Password</a>
                </div>
</form>
                <?php if(isset($_POST['login'])){
                        $username = $_POST['username'];
                        $password = $_POST['password'];
                        $password = $password;

                          $query = "SELECT * FROM user_details WHERE Username = '$username' AND Password = '$password'";
                          $result = $con->query($query);
                          $num = $result->num_rows;
                          $final = $result->fetch_assoc();
                    
                          if($num > 0){
                    
                            $_SESSION['ID'] = $final['User_ID'];
                            $_SESSION['NO'] = 1;

                            echo "<script type = \"text/javascript\">
                          window.location = (\"newhome.php\")
                          </script>";
                    
                          }
                    
                          else{
                    
                            echo "<div class='alert alert-danger' role='alert' style='margin-top: 50px;'>
                            Invalid Username/Password!
                            </div>";
                    
                          }
                        
                    }
                ?>
            </div>
        </div>
    </body>
    <script>
  function myFunction() {
        var element = document.body;
        element.dataset.bsTheme =
          element.dataset.bsTheme == "light" ? "dark" : "light";
      }
      </script>
</html> 

