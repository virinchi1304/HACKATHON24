<?php
include "dbcon.php";
session_start();
if($_SESSION['NO'] != 1){
  echo "<script type = \"text/javascript\">
              window.location = (\"login.php\")
              </script>";
}
?>
<html>
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Customize</title>
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css"
      rel="stylesheet"
      integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD"
      crossorigin="anonymous"
    />
    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.2/font/bootstrap-icons.css"
      integrity="sha384-b6lVK+yci+bfDmaY1u0zE8YYJt0TZxLEAFyYSLHId4xoVvsrQu3INevFKo+Xir8e"
      crossorigin="anonymous"
    />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.3.0/font/bootstrap-icons.css">
  </head>
  <body data-bs-theme="light">
  <nav class="navbar navbar-dark bg-dark" style="height:70px;" id="nav">
            <div class="container-fluid">
            <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST" style="margin-top:15px;">
              <a class="navbar-brand" href="home.php">GlobeTrotter</a>
              <a class="btn btn-secondary" onclick="myFunction()" role="switch" style="margin-left:950px;">Switch Mode</a>
              <button  type="submit" class="btn btn-danger" style="margin-left:10px;" name = "logout">Logout</button>
              <?php
                if(isset($_POST['logout'])){
                session_destroy();
                echo "<script type = \"text/javascript\">
                window.location = (\"home.php\")
                </script>";
                }
            ?>
              </form>
            </div>
        </nav>
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12">
          <div class="container-fluid p-2 align-items-center">
            <div class="d-flex justify-content-around">
              <button
                class="btn bg-success text-white btn-sm rounded-pill"
                style="width: 2rem; height: 2rem"
                data-bs-toggle="collapse"
                data-bs-target="#company1"
                aria-expanded="true"
                aria-controls="company1"
                onclick="stepFunction(event)"
              >
                1
              </button>
              <span
                class="bg-success w-25 rounded mt-auto mb-auto me-1 ms-1"
                style="height: 0.2rem"
              >
              </span>
              <button
                class="btn bg-success text-white btn-sm rounded-pill"
                style="width: 2rem; height: 2rem"
                data-bs-toggle="collapse"
                data-bs-target="#company2"
                aria-expanded="false"
                aria-controls="company3"
                onclick="stepFunction(event)"
              >
                2
              </button>
              <span
                class="bg-success w-25 rounded mt-auto mb-auto me-1 ms-1"
                style="height: 0.2rem"
              >
              </span>
              <button
                class="btn bg-success text-white btn-sm rounded-pill"
                style="width: 2rem; height: 2rem"
                data-bs-toggle="collapse"
                data-bs-target="#company3"
                aria-expanded="false"
                aria-controls="company3"
                onclick="stepFunction(event)"
              >
                3
              </button>
            </div>
          </div>
          <div class="collapse show" id="company1" style="margin-top:25px;">
            <div class="display-4">Choose</div>
            <p>
            <form action="<?php echo $_SERVER['PHP_SELF']; ?>"method="POST">
            <label class="form-label" style="margin-top:20px;">Type of Visit</label>
            <select class = 'form-select' name="type" id="" style="width:400px;">
            <option selected>Select Type</option>
                <option>
                        Solo
                </option>
                <option>
                        Couple
                </option>
                <option>
                        Family
                </option>
            </select>
            <label class="form-label" style="margin-top:20px;">Duration of Visit </label>
            <select class = 'form-select' name="duration" id="" style="width:400px;">
            <option selected>Select Duration</option>
                <option>
                        Less than a Week
                </option>
                <option>
                        Around a Week
                </option>
                <option>
                        More than a Week
                </option>
            </select>
            <div style="margin-top:20px;width:400px;">
                    <label for="dob" class="form-label">Start Date</label>
                    <input type="date" class="form-control" name="start_date" id="dob">
                </div>
            <div style="margin-top:35px;">
                    <button type="submit" class="btn btn-outline-success" style="min-width:400px;" name="next" type="submit" value="next">Next</button>
            </div>
            <?php
            if(isset($_POST['next'])){
              echo "<br>";
              echo "<div class='alert alert-success' role='alert' style= 'max-width: 35%; text-align: center'>
              Move on to the next steps to find the locations that are best suited for you
              </div>";
            }
            ?>
            </form>
            </p>
          </div>
          <div class="collapse" id="company2">
            <div class="display-4">Hidden Gems</div>
            <br>
            <p>
              <?php
              if(isset($_POST['next'])){
                $type = $_POST['type'];
                $duration = $_POST['duration'];
                if($duration == 'Less than a Week'){
                  $query = "SELECT * from place_details where Place_ID < '4'";
                  $result = $con->query($query);
                  $num = $result->num_rows;
                  $final = $result->fetch_all(MYSQLI_ASSOC);
                  print_r($final[0]['Place_Name']);
                  echo "<br><br>";
                  print_r($final[0]['Information']);
                  echo "<br><br><br>";
                  print_r($final[1]['Place_Name']);
                  echo "<br><br>";
                  print_r($final[1]['Information']);
                  echo "<br><br><br>";
                  print_r($final[2]['Place_Name']);
                  echo "<br><br>";
                  print_r($final[2]['Information']);
                }
                elseif ($duration == 'Around a Week') {
                  $query = "SELECT * from place_details where Place_ID < '7'";
                  $result = $con->query($query);
                  $num = $result->num_rows;
                  $final = $result->fetch_all(MYSQLI_ASSOC);
                  print_r($final[5]['Place_Name']);
                  echo "<br><br>";
                  print_r($final[5]['Information']);
                  echo "<br><br><br>";
                  print_r($final[4]['Place_Name']);
                  echo "<br><br>";
                  print_r($final[4]['Information']);
                  echo "<br><br><br>";
                  print_r($final[3]['Place_Name']);
                  echo "<br><br>";
                  print_r($final[3]['Information']);
                  echo "<br><br><br>";
                  print_r($final[2]['Place_Name']);
                  echo "<br><br>";
                  print_r($final[2]['Information']);
                  echo "<br><br><br>";
                  print_r($final[1]['Place_Name']);
                  echo "<br><br>";
                  print_r($final[1]['Information']);
                  echo "<br><br><br>";
                  print_r($final[0]['Place_Name']);
                  echo "<br><br>";
                  print_r($final[0]['Information']);
                }
                elseif($duration == 'More than a Week'){
                  $query = "SELECT * from place_details where Place_ID < '8'";
                  $result = $con->query($query);
                  $num = $result->num_rows;
                  $final = $result->fetch_all(MYSQLI_ASSOC);
                  print_r($final[6]['Place_Name']);
                  echo "<br><br>";
                  print_r($final[6]['Information']);
                  echo "<br><br><br>";
                  print_r($final[5]['Place_Name']);
                  echo "<br><br>";
                  print_r($final[5]['Information']);
                  echo "<br><br><br>";
                  print_r($final[4]['Place_Name']);
                  echo "<br><br>";
                  print_r($final[4]['Information']);
                  echo "<br><br><br>";
                  print_r($final[3]['Place_Name']);
                  echo "<br><br>";
                  print_r($final[3]['Information']);
                  echo "<br><br><br>";
                  print_r($final[2]['Place_Name']);
                  echo "<br><br>";
                  print_r($final[2]['Information']);
                  echo "<br><br><br>";
                  print_r($final[1]['Place_Name']);
                  echo "<br><br>";
                  print_r($final[1]['Information']);
                  echo "<br><br><br>";
                  print_r($final[0]['Place_Name']);
                  echo "<br><br>";
                  print_r($final[0]['Information']);
                }
                else{
                  echo "<br>";
                  echo "<div class='alert alert-warning' role='alert' style= 'max-width: 35%; text-align: center'>
                  Tell us how long you plan to vacation. We will show you a tailor made plan!
                  Move back to step 1 to select duration
                  </div>";
                }
              }
              else{
                echo "Select Your Specifications to find Ideal Locations.";
              }
              ?>
            </p>
          </div>
          <div class="collapse" id="company3">
            <div class="display-4">Your Perfect Plan is Here!</div>
            <p>
              <?php
              if(isset($_POST['next'])){
                $type = $_POST['type'];
                $duration = $_POST['duration'];
                $start_date = $_POST['start_date'];
                $order_date = date('Y-m-d');
                if($duration == 'Less than a Week'){
                  $query = "SELECT * from place_details where Place_ID < '4'";
                  $result = $con->query($query);
                  $num = $result->num_rows;
                  $final = $result->fetch_all(MYSQLI_ASSOC);
                  echo "<br>";
                  echo "DAY 1";
                  $query1 = "SELECT * from hotel_details where Hotel_ID in (SELECT Hotel_ID from place_details where Place_ID = '1')";
                  $result1 = $con->query($query1);
                  $num1 = $result1->num_rows;
                  $final1 = $result1->fetch_all(MYSQLI_ASSOC);
                  $query2 = "SELECT * from restaurant_details where Restaurant_ID in (SELECT Restaurant_ID from place_details where Place_ID = '1' or Place_ID = '2' or Place_ID = '3')";
                  $result2 = $con->query($query2);
                  $num2 = $result2->num_rows;
                  $final2 = $result2->fetch_all(MYSQLI_ASSOC);
                  echo "<br><br>";
                  print_r("On your first day, you shall check into the ".$final1[0]['Hotel_Name']);
                  print_r(". From there the ".$final[0]['Place_Name']."is just 5 Minutes away");
                  print_r(". Once you have thoroughly enjoyed the beautiful ".$final[0]['Place_Name']." you can pay ".$final2[0]['Restaurant_Name'].
                  " a vist and savour the delicious food there.");
                  echo "<br>";
                  print_r(" When you are done, you can go back to the ".$final1[0]['Hotel_Name']." and prepare for the next day");

                  echo "<br><br><br>";
                  echo "DAY 2";
                  echo "<br><br>";
                  print_r(" From your Hotel, ".$final1[0]['Hotel_Name']." you can start the second day of your trip.");
                  print_r(" From there the ".$final[1]['Place_Name']."would be your next stop");
                  print_r(". Once you have thoroughly enjoyed the beautiful ".$final[1]['Place_Name']." you can pay ".$final2[1]['Restaurant_Name'].
                  " a vist and savour the tasty food there.");
                  echo "<br>";
                  print_r(" When you are done, you can go back to the ".$final1[0]['Hotel_Name']." and prepare for the next day");

                  echo "<br><br><br>";
                  echo "DAY 3";
                  echo "<br><br>";
                  print_r(" From your Hotel, ".$final1[0]['Hotel_Name']." you can start the Third and final day of your trip.");
                  print_r(" From there the ".$final[2]['Place_Name']."would be your last stop");
                  print_r(". Once you have thoroughly enjoyed the gorgeous ".$final[2]['Place_Name']." you can pay ".$final2[2]['Restaurant_Name'].
                  " a vist and savour the tasty food there.");
                  echo "<br>";
                  print_r(" When you are done, you can end your day and your trip at ".$final1[0]['Hotel_Name']." or extending as you please");

                  echo "<br><br><br>";
                  print_r("Your total Bill come up to be,");
                  echo "<br>";
                  print_r("₹ ");
                  $total_cost = ((int)$final1[0]['Cost_Per_Day'])*3 + ((int)$final2[0]['Cost_Per_Day'])+ 3000*3;
                  print_r($total_cost);
                  $query24 = "INSERT INTO planner_details (User_ID,Start_Date,Cost_of_Plan,Order_Date) 
                  values ('$_SESSION[ID]','$start_date','$total_cost','$order_date')";
                  $result24 = $con->query($query24);
                  echo "<br><br>";
                  echo "<div style='margin-top:35px;'>
                  <a type='submit' class='btn btn-outline-success' href='\GlobeTrotter\payment.php' style='min-width:465px;' name='pay' type='submit' value='next'>Proceed to Pay</a>
                  </div>";
                  if(isset($_POST['pay'])){
                    echo "<script type = \"text/javascript\">
                          window.location = (\"payment.php\")
                          </script>";
                  }
                }
                elseif($duration == 'Around a Week'){
                  $query = "SELECT * from place_details where Place_ID < '7'";
                  $result = $con->query($query);
                  $num = $result->num_rows;
                  $final = $result->fetch_all(MYSQLI_ASSOC);
                  $query1 = "SELECT * from hotel_details where Hotel_ID in (SELECT Hotel_ID from place_details where Place_ID = '4' or Place_ID = '1')";
                  $result1 = $con->query($query1);
                  $num1 = $result1->num_rows;
                  $final1 = $result1->fetch_all(MYSQLI_ASSOC);
                  $query2 = "SELECT * from restaurant_details where Restaurant_ID in (SELECT Restaurant_ID from place_details where Place_ID = '1' or Place_ID = '2' or Place_ID = '3' or Place_ID = '4' or Place_ID = '5' or Place_ID = '6')";
                  $result2 = $con->query($query2);
                  $num2 = $result2->num_rows;
                  $final2 = $result2->fetch_all(MYSQLI_ASSOC);
                  echo "<br>";
                  echo "DAY 1";
                  echo "<br><br>";
                  print_r("On your first day, you shall check into the ".$final1[1]['Hotel_Name']);
                  print_r(". From there the ".$final[5]['Place_Name']."is just 5 Minutes away");
                  print_r(". Once you have thoroughly enjoyed the beautiful ".$final[5]['Place_Name']." you can pay ".$final2[5]['Restaurant_Name'].
                  " a vist and savour the delicious food there.");
                  echo "<br>";
                  print_r(" When you are done, you can go back to the ".$final1[1]['Hotel_Name']." and prepare for the next day");

                  echo "<br><br><br>";
                  echo "DAY 2";
                  echo "<br><br>";
                  print_r(" From your Hotel, ".$final1[1]['Hotel_Name']." you can start the second day of your trip.");
                  print_r(" From there the ".$final[4]['Place_Name']." would be your next stop");
                  print_r(". Once you have thoroughly enjoyed the beautiful ".$final[4]['Place_Name']." you can pay ".$final2[4]['Restaurant_Name'].
                  " a vist and savour the tasty food there.");
                  echo "<br>";
                  print_r(" When you are done, you can go back to the ".$final1[1]['Hotel_Name']." and prepare for the next day");

                  echo "<br><br><br>";
                  echo "DAY 3";
                  echo "<br><br>";
                  print_r(" From your Hotel, ".$final1[1]['Hotel_Name']." you can start the Third day of your trip.");
                  print_r(" From there the ".$final[3]['Place_Name']." would be your next stop");
                  print_r(". Once you have thoroughly enjoyed the beautiful ".$final[3]['Place_Name']." you can pay ".$final2[3]['Restaurant_Name'].
                  " a vist and savour the tasty food there.");
                  echo "<br>";
                  print_r(" When you are done, you can go back to the ".$final1[1]['Hotel_Name']." and prepare for the next day");

                  echo "<br><br><br>";
                  echo "DAY 4";
                  echo "<br><br>";
                  print_r(" You can now move to the , ".$final1[0]['Hotel_Name'].". Once you have settled in, you can continue with your trip.");
                  print_r(" From your Hotel the ".$final[2]['Place_Name']." would be your next stop");
                  print_r(". Once you have thoroughly enjoyed the beautiful ".$final[2]['Place_Name']." you can pay ".$final2[2]['Restaurant_Name'].
                  " a vist and savour the tasty food there.");
                  echo "<br>";
                  print_r(" When you are done, you can go back to the ".$final1[0]['Hotel_Name']." and prepare for the next day");
                  
                  echo "<br><br><br>";
                  echo "DAY 5";
                  echo "<br><br>";
                  print_r(" From your Hotel, ".$final1[0]['Hotel_Name']." you can start the Fifth day of your trip.");
                  print_r(" From there the ".$final[1]['Place_Name']." would be your next stop");
                  print_r(". Once you have thoroughly enjoyed the beautiful ".$final[1]['Place_Name']." you can pay ".$final2[1]['Restaurant_Name'].
                  " a vist and savour the tasty food there.");
                  echo "<br>";
                  print_r(" When you are done, you can go back to the ".$final1[0]['Hotel_Name']." and prepare for the next day");

                  echo "<br><br><br>";
                  echo "DAY 6";
                  echo "<br><br>";
                  print_r(" From your Hotel, ".$final1[0]['Hotel_Name']." you can start the final day of your trip.");
                  print_r(" From there the ".$final[0]['Place_Name']." would be your last stop");
                  print_r(". Once you have thoroughly enjoyed the gorgeous ".$final[0]['Place_Name']." you can pay ".$final2[0]['Restaurant_Name'].
                  " a vist and savour the tasty food there.");
                  echo "<br>";
                  print_r(" When you are done, you can end your day and your trip at ".$final1[0]['Hotel_Name']." or extending as you please");

                  echo "<br><br><br>";
                  print_r("Your total Bill come up to be,");
                  echo "<br>";
                  print_r(" ₹");
                  $total_cost = ((int)$final1[0]['Cost_Per_Day'])*3 + ((int)$final1[1]['Cost_Per_Day'])*3 + ((int)$final2[0]['Cost_Per_Day']) + ((int)$final2[1]['Cost_Per_Day']) + ((int)$final2[2]['Cost_Per_Day']) + ((int)$final2[3]['Cost_Per_Day']) + ((int)$final2[4]['Cost_Per_Day']) + ((int)$final2[5]['Cost_Per_Day']) + 2000*6;
                  print($total_cost);
                  $query24 = "INSERT INTO planner_details (User_ID,Start_Date,Cost_of_Plan,Order_Date) 
                  values ('$_SESSION[ID]','$start_date','$total_cost','$order_date')";
                  $result24 = $con->query($query24);
                  echo "<br><br>";
                  echo "<form action='<?php echo $_SERVER[PHP_SELF]; ?>' method='POST' style='margin-top:15px;''><div style=margin-top:35px;>
                  <a type='submit' class='btn btn-outline-success' style='min-width:465px;' href='\GlobeTrotter\payment.php' name='next' type='submit' value='next'>Proceed to Pay</a>
                  </div> </form>";
                  if(isset($_POST['pay'])){
                    echo "<script type = \"text/javascript\">
                          window.location = (\"payment.php\")
                          </script>";
                  }
                }
                elseif($duration == 'More than a Week'){
                  $query = "SELECT * from place_details where Place_ID < '8'";
                  $result = $con->query($query);
                  $num = $result->num_rows;
                  $final = $result->fetch_all(MYSQLI_ASSOC);
                  $query1 = "SELECT * from hotel_details where Hotel_ID in (SELECT Hotel_ID from place_details where Place_ID = '4' or Place_ID = '1' or  Place_ID = '7')";
                  $result1 = $con->query($query1);
                  $num1 = $result1->num_rows;
                  $final1 = $result1->fetch_all(MYSQLI_ASSOC);
                  $query2 = "SELECT * from restaurant_details where Restaurant_ID in (SELECT Restaurant_ID from place_details where Place_ID = '1' or Place_ID = '2' or Place_ID = '3' or Place_ID = '4' or Place_ID = '5' or Place_ID = '6' or Place_ID = '7')";
                  $result2 = $con->query($query2);
                  $num2 = $result2->num_rows;
                  $final2 = $result2->fetch_all(MYSQLI_ASSOC);

                  echo "<br>";
                  echo "DAY 1 through 7";
                  echo "<br><br>";
                  print_r("On your first day, you shall check into the ".$final1[2]['Hotel_Name']);
                  print_r(". From there the ".$final[6]['Place_Name']."is just 5 Minutes away");
                  print_r(". Once you have thoroughly enjoyed the beautiful lush greenary of the ".$final[6]['Place_Name']." you can pay ".$final2[6]['Restaurant_Name'].
                  " a vist and savour the delicious food there. Appart from this, there are a variety of other nearby hills and attractions that you can visit relish in. you can also participate in festivals such as the flower festival");
                  echo "<br>";
                  print_r(" When you are done, you can go back to the ".$final1[2]['Hotel_Name']." and prepare for the next day");

                  echo "<br><br><br>";
                  echo "DAY 8";
                  echo "<br><br>";
                  print_r(" You can now move to the, ".$final1[1]['Hotel_Name'].". Once you have settled in, you can continue with your trip.");
                  print_r(" From your Hotel the ".$final[5]['Place_Name']." would be your next stop");
                  print_r(". Once you have thoroughly enjoyed the beautiful ".$final[5]['Place_Name']." you can pay ".$final2[5]['Restaurant_Name'].
                  " a vist and savour the tasty food there.");
                  echo "<br>";
                  print_r(" When you are done, you can go back to the ".$final1[1]['Hotel_Name']." and prepare for the next day");

                  echo "<br><br><br>";
                  echo "DAY 9";
                  echo "<br><br>";
                  print_r(" From your Hotel, ".$final1[1]['Hotel_Name']." you can start the Ninth day of your trip.");
                  print_r(" From there the ".$final[4]['Place_Name']." would be your next stop");
                  print_r(". Once you have thoroughly enjoyed the beautiful ".$final[4]['Place_Name']." you can pay ".$final2[4]['Restaurant_Name'].
                  " a vist and savour the tasty food there.");
                  echo "<br>";
                  print_r(" When you are done, you can go back to the ".$final1[1]['Hotel_Name']." and prepare for the next day");

                  echo "<br><br><br>";
                  echo "DAY 10";
                  echo "<br><br>";
                  print_r(" From your Hotel, ".$final1[1]['Hotel_Name']." you can start the Tenth day of your trip.");
                  print_r(" From there the ".$final[3]['Place_Name']." would be your next stop");
                  print_r(". Once you have thoroughly enjoyed the beautiful ".$final[3]['Place_Name']." you can pay ".$final2[3]['Restaurant_Name'].
                  " a vist and savour the tasty food there.");
                  echo "<br>";
                  print_r(" When you are done, you can go back to the ".$final1[1]['Hotel_Name']." and prepare for the next day");

                  echo "<br><br><br>";
                  echo "DAY 11";
                  echo "<br><br>";
                  print_r(" You can now move to the , ".$final1[0]['Hotel_Name'].". Once you have settled in, you can continue with your trip.");
                  print_r(" From your Hotel the ".$final[2]['Place_Name']." would be your next stop");
                  print_r(". Once you have thoroughly enjoyed the beautiful ".$final[2]['Place_Name']." you can pay ".$final2[2]['Restaurant_Name'].
                  " a vist and savour the tasty food there.");
                  echo "<br>";
                  print_r(" When you are done, you can go back to the ".$final1[0]['Hotel_Name']." and prepare for the next day");
                  
                  echo "<br><br><br>";
                  echo "DAY 12";
                  echo "<br><br>";
                  print_r(" From your Hotel, ".$final1[0]['Hotel_Name']." you can start the Twelfth day of your trip.");
                  print_r(" From there the ".$final[1]['Place_Name']." would be your next stop");
                  print_r(". Once you have thoroughly enjoyed the beautiful ".$final[1]['Place_Name']." you can pay ".$final2[1]['Restaurant_Name'].
                  " a vist and savour the tasty food there.");
                  echo "<br>";
                  print_r(" When you are done, you can go back to the ".$final1[0]['Hotel_Name']." and prepare for the next day");

                  echo "<br><br><br>";
                  echo "DAY 13";
                  echo "<br><br>";
                  print_r(" From your Hotel, ".$final1[0]['Hotel_Name']." you can start the final day of your trip.");
                  print_r(" From there the ".$final[0]['Place_Name']." would be your last stop");
                  print_r(". Once you have thoroughly enjoyed the gorgeous ".$final[0]['Place_Name']." you can pay ".$final2[0]['Restaurant_Name'].
                  " a vist and savour the tasty food there.");
                  echo "<br>";
                  print_r(" When you are done, you can end your day and your trip at ".$final1[0]['Hotel_Name']." or extending as you please");

                  echo "<br><br><br>";
                  print_r("Your total Bill come up to be,");
                  echo "<br>";
                  print_r(" ₹");
                  $total_cost = ((int)$final1[0]['Cost_Per_Day'])*3 + ((int)$final1[1]['Cost_Per_Day'])*3 + ((int)$final1[2]['Cost_Per_Day'])*7 + ((int)$final2[0]['Cost_Per_Day']) + ((int)$final2[1]['Cost_Per_Day']) + ((int)$final2[2]['Cost_Per_Day']) + ((int)$final2[3]['Cost_Per_Day']) + ((int)$final2[4]['Cost_Per_Day']) + ((int)$final2[5]['Cost_Per_Day']) + ((int)$final2[6]['Cost_Per_Day'])*7 + 3000*13;
                  print($total_cost);
                  $query24 = "INSERT INTO planner_details (User_ID,Start_Date,Cost_of_Plan,Order_Date) 
                  values ('$_SESSION[ID]','$start_date','$total_cost','$order_date')";
                  $result24 = $con->query($query24);
                  echo "<br><br>"; ?>
                  <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST" style="margin-top:15px;">
                  <div style="margin-top:35px;">
                    <a type="submit" class="btn btn-outline-success" href='\GlobeTrotter\payment.php' style="min-width:465px;" name="pay" type="submit" value="pay">Proceed to Pay</a>
                  </div>
                </form><?php
                  if(isset($_POST['pay'])){
                    echo "<script type = \"text/javascript\">
                          window.location = (\"payment.php\")
                          </script>";
                  }
                }
                else{
                  echo "<br>";
                  echo "<div class='alert alert-warning' role='alert' style= 'max-width: 35%; text-align: center'>
                  Tell us how long you plan to vacation. We will show you a tailor made plan!
                  Move back to step 1 to select duration
                  </div>";
                }
              }
              ?>
            </p>
          </div>
        </div>
      </div>
    </div>
    <script>
      function myFunction() {
        var element = document.body;
        element.dataset.bsTheme =
          element.dataset.bsTheme == "light" ? "dark" : "light";
      }
      function stepFunction(event) {
        debugger;
        var element = document.getElementsByClassName("collapse");
        for (var i = 0; i < element.length; i++) {
          if (element[i] !== event.target.ariaControls) {
            element[i].classList.remove("show");
          }
        }
      }
    </script>

    <script
      src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"
      integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3"
      crossorigin="anonymous"
    ></script>
    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js"
      integrity="sha384-mQ93GR66B00ZXjt0YO5KlohRA5SY2XofN4zfuZxLkoj1gXtW8ANNCe9d5Y3eG5eD"
      crossorigin="anonymous"
    ></script>
  </body>
</html>