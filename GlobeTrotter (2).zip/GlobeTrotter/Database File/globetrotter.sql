-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 06, 2023 at 06:41 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `globetrotter`
--

-- --------------------------------------------------------

--
-- Table structure for table `feedback_details`
--

CREATE TABLE `feedback_details` (
  `Feedback_ID` int(11) NOT NULL,
  `User_ID` int(100) NOT NULL,
  `Place_ID` int(100) NOT NULL,
  `Comment` varchar(1000) NOT NULL,
  `Rating` int(10) NOT NULL,
  `Location_Suggested` varchar(1000) NOT NULL,
  `Feedback` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hotel_details`
--

CREATE TABLE `hotel_details` (
  `Hotel_ID` int(11) NOT NULL,
  `Hotel_Name` varchar(1000) NOT NULL,
  `Cost_Per_Day` int(100) NOT NULL,
  `Hotel_Address` varchar(1000) NOT NULL,
  `Contact_No` bigint(100) NOT NULL,
  `Contact_Email` varchar(1000) NOT NULL,
  `No_Of_Free_Rooms` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `hotel_details`
--

INSERT INTO `hotel_details` (`Hotel_ID`, `Hotel_Name`, `Cost_Per_Day`, `Hotel_Address`, `Contact_No`, `Contact_Email`, `No_Of_Free_Rooms`) VALUES
(1, 'The Lion Inn', 4025, 'main gate, Near visitor center, Auroville, Edayanchavadi, Tamil Nadu, Auroville, Puducherry 605101', 0, '', 4),
(2, 'Marina Inn', 2025, '55/31, Gandhi Irwin Rd, Egmore, Chennai, Tamil Nadu 600008', 4428192919, 'http://www.marinainn.in/', 6),
(3, 'Woodland Holiday Resort', 2300, 'Pallakaniyur village Thirupatur, Tamil Nadu 635853', 6382112274, 'http://woodlandholidayresort.com/', 4);

-- --------------------------------------------------------

--
-- Table structure for table `payment_details`
--

CREATE TABLE `payment_details` (
  `Payment_ID` int(100) NOT NULL,
  `User_ID` int(100) NOT NULL,
  `Full_Name` varchar(1000) NOT NULL,
  `Email` varchar(1000) NOT NULL,
  `Address` varchar(1000) NOT NULL,
  `City` varchar(1000) NOT NULL,
  `State` varchar(1000) NOT NULL,
  `Zip_Code` int(100) NOT NULL,
  `Name_on_Card` varchar(1000) NOT NULL,
  `Credit_card_Number` int(100) NOT NULL,
  `Expiry_Month` varchar(1000) NOT NULL,
  `Expiry_Year` date NOT NULL,
  `CVV` int(3) NOT NULL,
  `Planner_ID` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `place_details`
--

CREATE TABLE `place_details` (
  `Place_ID` int(11) NOT NULL,
  `Place_Name` varchar(1000) NOT NULL,
  `Information` varchar(1000) NOT NULL,
  `Hotel_ID` int(100) NOT NULL,
  `Restaurant_ID` int(100) NOT NULL,
  `Visit_Start` date NOT NULL,
  `Visit_End` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `place_details`
--

INSERT INTO `place_details` (`Place_ID`, `Place_Name`, `Information`, `Hotel_ID`, `Restaurant_ID`, `Visit_Start`, `Visit_End`) VALUES
(1, 'Matrimanthir', 'At the very centre of Auroville one finds the \'soul of the city\', the Matrimandir, situated in a large open area called \'Peace\', from where the future township will radiate outwards. The atmosphere is quiet and charged, and the area beautiful, even though work continues in the Gardens. ', 1, 1, '2023-11-01', '2024-03-31'),
(2, 'Oussudu Lake Bird Sanctuary', 'The coastal town of Puducherry, erstwhile Pondicherry, is a perfect blend of French and Indian architecture. It is an artificial lake built by the French and served as a source of drinking water for all its residents. Over the years, the lake has evolved into a wetland. sail through this beautiful wetland and witness the chirping of multitudes of colorful birds hovering all over the place.', 1, 2, '2023-10-01', '2024-03-31'),
(3, 'Bharathi Park', 'The scenic Bharathi park, also known as the government park adds to the old-world charm of the city. Located in the heart of the city, the park is carpeted with lush grass and surrounded by thick green trees. It is an ideal place to relax and unwind as you enjoy the green lawns and vibrant flower beds and has a fine blend of historical and natural features.', 1, 3, '2023-12-01', '2024-02-29'),
(4, 'Government Museum', 'The Government Museum Chennai, or Madras Museum, is among the oldest museums in the world, and the second oldest in India. It has a rich collection of artefacts detailing human history and culture.The museum is known for artefacts and bronze sculptures belonging to different South Indian dynasties. But the exhibits also include items from archaeology, geology, numismatics and other varied subjects. Government Museum Chennai even has the largest collection of Roman antiquities outside Europe.', 2, 4, '2023-11-01', '2024-02-29'),
(5, 'Canyon of Pallavaram', 'Out here, it’s nature max and the quiet and scenic vibes make it the perfect place to unwind. Also, it’s not close to the city so you can skip the traffic but not too far that you can’t get back in time. We hear that you can learn paddleboard yoga, a quirky form of yoga with Bay Of Life, a surf school. If ocean swimming is too intense for you, head to Ottiambakkam quarry to practice. Chill with a beer, do yoga, or cool off, your weekend plans are sorted. ', 2, 5, '2023-01-01', '2023-12-31'),
(6, 'DakshinaChitra Heritage Museum', '\r\nAbout DakshinaChitra\r\nDakshinaChitra is an exciting cross cultural living museum of art, architecture, lifestyles, crafts and performing arts of South India. The main mission is to exhibit, promote and preserve aspects of the broader, more inclusive cultures of the states and to bring these arts to the public in a participative, enjoyable and engaging way. DakshinaChitra has a collection of 18 authentic historical houses with contextual exhibitions in each house. All the houses bought and reconstructed at DakshinaChitra had been given for demolition by their owners. The authentic homes in a regional vernacular style are purchased, taken down, transported and reconstructed by artisans ( Stapathis) of the regions from where the houses came.', 2, 6, '2023-11-01', '2024-02-29'),
(7, 'Yelagiri Hills', 'Yelagiri is not only famous for adventures and camping but also for beautiful sightseeing and visiting a few temples. Yelagiri is also most famous for its summer festival which is celebrated at the end of the month of May and the festival will be conducted by the Tamil Nadu tourism development board. It is surrounded by eye catching orchards, rose gardens, and a lush green valley. There is no doubt that a traveler or an adventurer will find plenty of places and sites to explore as the beautiful hills and valleys of the district allows you to give a treat to your eyes with its exotic locales. ', 3, 7, '2022-11-01', '2024-05-31');

-- --------------------------------------------------------

--
-- Table structure for table `planner_details`
--

CREATE TABLE `planner_details` (
  `Planner_ID` int(11) NOT NULL,
  `User_ID` int(100) NOT NULL,
  `Start_Date` date NOT NULL,
  `Cost_of_Plan` int(100) NOT NULL,
  `Order_Date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `restaurant_details`
--

CREATE TABLE `restaurant_details` (
  `Restaurant_ID` int(11) NOT NULL,
  `Restaurant_Name` varchar(1000) NOT NULL,
  `Cost_Per_Day` int(100) NOT NULL,
  `Restaurant_Address` varchar(1000) NOT NULL,
  `Contact_No` bigint(100) NOT NULL,
  `Contact_Email` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `restaurant_details`
--

INSERT INTO `restaurant_details` (`Restaurant_ID`, `Restaurant_Name`, `Cost_Per_Day`, `Restaurant_Address`, `Contact_No`, `Contact_Email`) VALUES
(1, '\r\nThe Pizza Planet Cafe & Restaurant', 1500, 'MDR1115, Auroville Rd, Auroville, Kuilapalayam, Tamil Nadu 605101', 4132623344, ''),
(2, 'Sri Sai Baba Tiffen Center', 1000, 'opp. to Beer Factory, Kurumbapet, Housing Board, Puducherry, 605009', 9095148013, ''),
(3, 'Cafe Xtasi', 1000, '245, Mission St, Opposite VOC School, MG Road Area, Puducherry, 605001', 4134209062, ''),
(4, 'Palmshore Restaurant Egmore', 1500, 'No 99, 59, Pantheon Rd, opp. Govt. Museum, Egmore, Chennai, Tamil Nadu 600008', 4441004100, ''),
(5, 'Grace Restaurant', 1500, 'No 131, 132, DGQA Rd, B.V. Nagar, Nanganallur, Chennai, Tamil Nadu 600114', 0, ''),
(6, 'The chennai bistro', 1000, 'R6FR+23M, SH 49, Muthukadu, Tamil Nadu 603103', 7305663336, ''),
(7, 'Eat Tamizha', 1500, 'Opp. Old Fakir Dharga Gate, Jolarpettai, Tirupathur, Tamil Nadu 635853', 8807372516, '');

-- --------------------------------------------------------

--
-- Table structure for table `user_details`
--

CREATE TABLE `user_details` (
  `User_ID` int(11) NOT NULL,
  `Title` varchar(100) NOT NULL,
  `First_Name` varchar(1000) NOT NULL,
  `Last_Name` varchar(1000) NOT NULL,
  `Username` varchar(1000) NOT NULL,
  `Password` varchar(1000) NOT NULL,
  `Marital_Status` varchar(1000) NOT NULL,
  `Area_Code` int(100) NOT NULL,
  `Mobile_Number` int(100) NOT NULL,
  `Gender` varchar(100) NOT NULL,
  `Address` varchar(1000) NOT NULL,
  `Email_ID` varchar(1000) NOT NULL,
  `Aadhar_Number` int(100) NOT NULL,
  `Date_Of_Birth` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_details`
--

INSERT INTO `user_details` (`User_ID`, `Title`, `First_Name`, `Last_Name`, `Username`, `Password`, `Marital_Status`, `Area_Code`, `Mobile_Number`, `Gender`, `Address`, `Email_ID`, `Aadhar_Number`, `Date_Of_Birth`) VALUES
(2, 'Mr.', 'B.Revanth', 'Subramaniam', 'Revanth', 'Typical123', 'Single', 0, 2147483647, 'Male', 'No 4/ 15,1st main road,chennai,TN,600018,india', 'e0421048@sret.edu.in', 2147483647, '2003-09-06');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `feedback_details`
--
ALTER TABLE `feedback_details`
  ADD PRIMARY KEY (`Feedback_ID`),
  ADD KEY `Feedback_fk_1` (`User_ID`),
  ADD KEY `Feedback_fk_2` (`Place_ID`);

--
-- Indexes for table `hotel_details`
--
ALTER TABLE `hotel_details`
  ADD PRIMARY KEY (`Hotel_ID`);

--
-- Indexes for table `payment_details`
--
ALTER TABLE `payment_details`
  ADD PRIMARY KEY (`Payment_ID`),
  ADD KEY `payment_fk_1` (`User_ID`),
  ADD KEY `payment_fk_2` (`Planner_ID`);

--
-- Indexes for table `place_details`
--
ALTER TABLE `place_details`
  ADD PRIMARY KEY (`Place_ID`),
  ADD KEY `place_fk_1` (`Hotel_ID`),
  ADD KEY `place_fk_2` (`Restaurant_ID`);

--
-- Indexes for table `planner_details`
--
ALTER TABLE `planner_details`
  ADD PRIMARY KEY (`Planner_ID`),
  ADD KEY `planner_fk_1` (`User_ID`);

--
-- Indexes for table `restaurant_details`
--
ALTER TABLE `restaurant_details`
  ADD PRIMARY KEY (`Restaurant_ID`);

--
-- Indexes for table `user_details`
--
ALTER TABLE `user_details`
  ADD PRIMARY KEY (`User_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `feedback_details`
--
ALTER TABLE `feedback_details`
  MODIFY `Feedback_ID` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hotel_details`
--
ALTER TABLE `hotel_details`
  MODIFY `Hotel_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `payment_details`
--
ALTER TABLE `payment_details`
  MODIFY `Payment_ID` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `place_details`
--
ALTER TABLE `place_details`
  MODIFY `Place_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `planner_details`
--
ALTER TABLE `planner_details`
  MODIFY `Planner_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `restaurant_details`
--
ALTER TABLE `restaurant_details`
  MODIFY `Restaurant_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `user_details`
--
ALTER TABLE `user_details`
  MODIFY `User_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `feedback_details`
--
ALTER TABLE `feedback_details`
  ADD CONSTRAINT `Feedback_fk_1` FOREIGN KEY (`User_ID`) REFERENCES `user_details` (`User_ID`),
  ADD CONSTRAINT `Feedback_fk_2` FOREIGN KEY (`Place_ID`) REFERENCES `place_details` (`Place_ID`);

--
-- Constraints for table `payment_details`
--
ALTER TABLE `payment_details`
  ADD CONSTRAINT `payment_fk_1` FOREIGN KEY (`User_ID`) REFERENCES `user_details` (`User_ID`),
  ADD CONSTRAINT `payment_fk_2` FOREIGN KEY (`Planner_ID`) REFERENCES `planner_details` (`Planner_ID`);

--
-- Constraints for table `place_details`
--
ALTER TABLE `place_details`
  ADD CONSTRAINT `place_fk_1` FOREIGN KEY (`Hotel_ID`) REFERENCES `hotel_details` (`Hotel_ID`),
  ADD CONSTRAINT `place_fk_2` FOREIGN KEY (`Restaurant_ID`) REFERENCES `restaurant_details` (`Restaurant_ID`);

--
-- Constraints for table `planner_details`
--
ALTER TABLE `planner_details`
  ADD CONSTRAINT `planner_fk_1` FOREIGN KEY (`User_ID`) REFERENCES `user_details` (`User_ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
