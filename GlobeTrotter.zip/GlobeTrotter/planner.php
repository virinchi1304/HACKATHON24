<?php
include "dbcon.php";
session_start();
?>
<html>
    <head>
        <title>Customize</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-aFq/bzH65dt+w6FI2ooMVUpc+21e0SRygnTpmBvdBgSdnuTN7QbdgL+OapgHtvPp" crossorigin="anonymous">
        <style>
            :root {
    --prm-color: #0381ff;
    --prm-gray: #b1b1b1;
}

.steps {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 2rem;
    position: relative;
}

.step-button {
    width: 50px;
    height: 50px;
    border-radius: 50%;
    border: none;
    background-color: var(--prm-gray);
    transition: .4s;
}

.step-button[aria-expanded="true"] {
    width: 60px;
    height: 60px;
    background-color: var(--prm-color);
    color: #fff;
}

.done {
    background-color: var(--prm-color);
    color: #fff;
}

.step-item {
    z-index: 10;
    text-align: center;
}

#progress {
  -webkit-appearance:none;
    position: absolute;
    width: 95%;
    z-index: 5;
    height: 10px;
    margin-left: 18px;
    margin-bottom: 18px;
}


#progress::-webkit-progress-value {
    background-color: var(--prm-color);
    transition: .5s ease;
    margin-top: 10px;
}

#progress::-webkit-progress-bar {
    background-color: var(--prm-gray);

}
        </style>
    </head>
    <body style="background-color: #f8f9fc;">
        <nav class="navbar navbar-dark bg-dark" style="height:70px;">
            <div class="container-fluid">
            <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
              <a class="navbar-brand" href="home.php">GlobeTrotter</a>
              <button  type="submit" class="btn btn-danger" name="logout" style="margin-left:1015px;">Logout</button>
            </div>

            <?php
            if(isset($_POST['logout'])){
                session_destroy();
                echo "<script type = \"text/javascript\">
                window.location = (\"home.php\")
                </script>";
            }
            ?>

        </nav>
        <main> 
<div class="container" style="margin-top:35px;">
<div class="accordion" id="accordionExample">
<div class="steps">
    <progress id="progress" value=0 max=100 ></progress>
    <div class="step-item">
        <button class="step-button text-center" type="button" data-bs-toggle="collapse"
            data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
            1
        </button>
    </div>
    <div class="step-item">
        <button class="step-button text-center collapsed" type="button" data-bs-toggle="collapse"
            data-bs-target="#collapseTwo" aria-expanded="false" name= '2' aria-controls="collapseTwo">
            2
        </button>
    </div>
    <div class="step-item">
        <button class="step-button text-center collapsed" type="button" data-bs-toggle="collapse"
            data-bs-target="#collapseThree" aria-expanded="false" name = '3' aria-controls="collapseThree">
            ✓
        </button>
    </div>
</div>

<div class="card">
    <div  id="headingOne">
    </div>

    <div id="collapseOne" class="collapse show" aria-labelledby="headingOne"
        data-bs-parent="#accordionExample">
        <div class="card-body">
            <form action="<?php echo $_SERVER['PHP_SELF']; ?>"method="POST">
        <div>
                        <label for="visit" class="form-label">Purpose of Visit</label>
                    </div>    
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="inlineRadioOptions"  id="inlineRadio1" value="Mr.">
                            <label class="form-check-label" for="inlineRadio1">Solo</label>
                          </div>
                          <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio2" value="Mrs.">
                            <label class="form-check-label" for="inlineRadio2">Couple</label>
                          </div>
                          <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio3" value="Miss">
                            <label class="form-check-label" for="inlineRadio2">Family</label>
                          </div>
                          <div style="margin-top:15px;">
                        <label for="date" class="form-label" >Begining date</label>
                        <input type="date" class="form-control" placeholder="First name"name = "date1" aria-label="First name" id="begin">
                    </div> 
                    <div style="margin-top:15px;">
                        <label for="date" class="form-label">Ending date</label>
                        <input type="date" class="form-control" placeholder="First name" name = "date2" aria-label="First name" id="end">
                    </div> 
                    <div style="margin-top:35px;text-align: center;">
                            <button class="btn btn-outline-primary" style="width:600px;" name="submit" type="submit">Submit</button>
                        </div>
</form>
        </div>
    </div>
</div>
<div class="card">
    <div  id="headingTwo">
    </div>
    <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-bs-parent="#accordionExample">
        <div class="card-title">
        Kalvarayan Hills
        </div>
        <div class="card-body">
        Natyanjali Dance Festival-The festival of dances. Dance has been considered to be the greatest ways of connecting with their souls and thus in turn connecting with our Oversoul, the Lord. Dance has been a crucial part of Indian culture throughout the ages. The Nataraja temple at Chidambaram in Tamil Nadu is the place where one can observe this dance festival in its greatest form.
         <br>
         <br>
         Thiruvaiyaru Festival-Thiruvaiyaru is a famous music festival that is celebrated in Thanjavur in Tamil Nadu.Every year in the month of January, a lot of composers come to Thanjavur for attending the festivities of this grand festival.
                 <br>
                 <br>
 
        Hotel : Double Tree Villa , 1316 per day
 
 <br>
 Mahamaham-Kumbakonam is the small town of Tamil Nadu where this festival is celebrated.

    </div>
</div>
</div>
</div>
 </main>
                
 <div class="card">
    <div  id="headingThree">
    </div>

    <div id="collapseThree" class="collapse show" aria-labelledby="headingThree"
        data-bs-parent="#accordionExample">
        <div class="card-body">
            <button class= "btn btn-primary btn-lg" style = "margin-left: 45%;" type = "submit" name="hello">Proceed to payment</button>
            <?php
            if(isset($_POST['hello'])) {

            echo "<script type = \"text/javascript\">
            window.location = (\"payment.php\")
            </script>";
            }
            ?>
        </div>
    </div>
</div>


    </body>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-U1DAWAznBHeqEIlVSCgzq+c9gqGAJn5c/t99JyeKa9xxaYpSvHU5awsuZVVFIhvj" crossorigin="anonymous"></script>
<script>
const stepButtons = document.querySelectorAll('.step-button');
const progress = document.querySelector('#progress');

Array.from(stepButtons).forEach((button,index) => {
    button.addEventListener('click', () => {
        progress.setAttribute('value', index * 100 /(stepButtons.length - 1) );//there are 3 buttons. 2 spaces.

        stepButtons.forEach((item, secindex)=>{
            if(index > secindex){
                item.classList.add('done');
            }
            if(index < secindex){
                item.classList.remove('done');
            }
        })
    })
})
</script>
</html> 
<?php if(isset($_POST['submit'])){
                        $type = $_POST['inlineRadioOptions'];
                        $date1 = $_POST['date1'];
                        $date2 = $_POST['date2'];
                        

                          $query = "INSERT into planner_details ( User_ID,Place_ID,Start_Date,End_Date,Order_ID,Hotel_ID,Res_ID) 
                          values ($_SESSION[ID],'2','$date1','$date2','1','1','1')";
                          $result = $con->query($query);
                
                        
                    }
 ?>
