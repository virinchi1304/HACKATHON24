<?php
include "dbcon.php";
session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<title>Processing</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-aFq/bzH65dt+w6FI2ooMVUpc+21e0SRygnTpmBvdBgSdnuTN7QbdgL+OapgHtvPp" crossorigin="anonymous">
</head>
<body style="background-color:#f8f9fc;">
<div class="text-center">
  <div class="spinner-border" role="status">
  </div>
</div>
<div class="text-center">
<span style="margin-left:10px;">Processing..</span></div>

<?php
session_destroy();
echo "<script type = \"text/javascript\">
            window.location = (\"home.php\")
            </script>";
?>
</body>
</html>
