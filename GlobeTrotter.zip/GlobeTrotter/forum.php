<html>
<?php
include "dbcon.php";
session_start();
?>
    <head>
        <title>Community Forum</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-aFq/bzH65dt+w6FI2ooMVUpc+21e0SRygnTpmBvdBgSdnuTN7QbdgL+OapgHtvPp" crossorigin="anonymous">
    </head>
    <body style="background-color: #f8f9fc;">
        <nav class="navbar navbar-dark bg-dark" style="height:70px;">
            <div class="container-fluid">
              <a class="navbar-brand" href="home.php">GlobeTrotter</a>
            </div>
        </nav>
        <div class="card" style="width:700px;height:580px;margin-top:15px;margin-left:25%;box-shadow: 10px 10px 5px  lightgray;">
            <div class="card-body">
              <h5 class="card-title" style="text-align:center;font-size: 30px;">Let us Know!</h5>
              <p class="card-text">
              <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
                    <div>   
                    <label for="name" class="form-label">Rate your experience out of 10</label>
                          <input type="number" class="form-control" placeholder="1-10" name="rate" aria-label="First name" id="rating">
                </div>
                <div style="margin-top:15px;">
                    <label for="occ" class="form-label">Comments</label>
                    <input type="text" class="form-control"name = "comment" style="width:500px;" id="occ">
                </div>
                <div style="margin-top:15px;">
                    <label for="occ" class="form-label">Suggest us locations to add</label>
                    <input type="text" class="form-control" name= "suggest" style="width:500px;" id="occ">
                </div>
                <div style="margin-top:15px;">
                    <label for="occ" class="form-label">Suggest us ways to improve customer experience</label>
                    <input type="text" class="form-control" style="width:500px;" name= "suggest2"id="occ">
                </div>
                <div style="margin-top:35px;text-align: center;">
                            <button class="btn btn-outline-primary" style="width:600px;" name="submit" type="submit">Submit</button>
                        </div>
                        </form>
              </p>
            </div>
          </div>
    </body>

    <?php
    if(isset($_POST['submit'])){
        $rate = $_POST['rate'];
        $suggest = $_POST['suggest'].",".$_POST['suggest2'];
        $comment = $_POST['comment'];
        $query2 = "INSERT INTO community_forum_details (User_ID,Rating,Comment,Feedback,Place_ID)
        values ('$_SESSION[ID]','$rate','$comment','$suggest','1')";
        $result2 = $con->query($query2);
        $query3 = "SELECT * FROM community_forum_details WHERE User_ID = '$_SESSION[ID]' AND Rating = '$rate' AND Comment = '$comment'  AND Feedback = '$suggest'";
        $result3 = $con->query($query3);
        $num2 = $result3->num_rows;
        if($num2>0){
        echo "<script type = \"text/javascript\">
        window.location = (\"home.php\")
        </script>";
    }
    }
    ?>
</html>