<?php
include "dbcon.php";
session_start();
?>
<html>
    <head>
        <title>Signup</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-aFq/bzH65dt+w6FI2ooMVUpc+21e0SRygnTpmBvdBgSdnuTN7QbdgL+OapgHtvPp" crossorigin="anonymous">
    </head>
    <body style="background-color: #f8f9fc;">
        <nav class="navbar navbar-dark bg-dark" style="height:70px;">
            <div class="container-fluid">
              <a class="navbar-brand" href="home.php">GlobeTrotter</a>
              <a href="login.php" type="button" class="btn btn-success" style="margin-left:1015px;">Login</a>
            </div>
        </nav>
        <div class="card" style="width:700px;height:1175px;margin-top:15px;margin-left:25%;box-shadow: 10px 10px 5px  lightgray;">
            <div class="card-body">
              <h5 class="card-title" style="text-align:center;font-size: 30px;">Signup Panel</h5>
              <p class="card-text">
              <form action="<?php echo $_SERVER['PHP_SELF']; ?>"method="POST">
                    <div>
                        <label for="title" class="form-label">Title</label>
                    </div>    
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio1" value="Mr.">
                            <label class="form-check-label" for="inlineRadio1">Mr.</label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio2" value="Mrs.">
                            <label class="form-check-label" for="inlineRadio2">Mrs.</label>
                        </div>
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="inlineRadioOptions" id="inlineRadio3" value="Miss">
                            <label class="form-check-label" for="inlineRadio2">Miss.</label>
                        </div>
                      <div style="margin-top:15px;">
                        <label for="name" class="form-label">Full Name</label>
                        <div class="row">
                            <div class="col">
                              <input type="text" class="form-control" name="first" placeholder="First name" aria-label="First name" id="fname">
                            </div>
                            <div class="col">
                              <input type="text" class="form-control" name="last"  placeholder="Last name" aria-label="Last name" id="lname">
                            </div>
                        </div>
                      </div>
                <div style="margin-top:15px;">
                    <label for="username" class="form-label">Username</label>
                    <input type="password" class="form-control" name="username" placeholder="username">
                </div> 
                <div style="margin-top:15px;">
                    <label for="password" class="form-label">Password</label>
                    <input type="password" class="form-control" name="password" placeholder="password">
                </div>
                <div style="margin-top:15px;">
                    <label for="dob" class="form-label">Date of Birth</label>
                    <input type="date" class="form-control" style="width:500px;" name="dob" id="dob">
                </div>
                <div style="margin-top:15px;">
                    <div>
                        <label for="gender" class="form-label">Gender</label>
                    </div>    
                        <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="inlineRadioOptions1" id="inlineRadio5" value="Male">
                            <label class="form-check-label" for="inlineRadiox">Male</label>
                          </div>
                          <div class="form-check form-check-inline">
                            <input class="form-check-input" type="radio" name="inlineRadioOptions1" id="inlineRadio6" value="Female">
                            <label class="form-check-label" for="inlineRadioy">Female</label>
                          </div>
                </div>
                <div style="margin-top:15px;">
                    <label for="mobile" class="form-label" >Mobile Number</label>
                    <div class="row">
                        <div class="col">
                          <input type="number" class="form-control" placeholder="Area Code" name="ac" style="width:125px;" id="ac">
                        </div>
                        <div class="col">
                          <input type="number" class="form-control" placeholder="Phone Number" name="mobile" style="width:500px;" id="number">
                        </div>
                      </div>
                </div>
                <div style="margin-top:15px;">
                    <label for="email" class="form-label">Email Address</label>
                    <div class="input-group mb-3">
                        <input type="text" class="form-control" name="email1" style="width:250px;" id="username">
                        <span class="input-group-text">@</span>
                        <input type="text" class="form-control" name="email2" style="width:100px;" id="domain">
                    </div>
                </div>
                <div style="margin-top:15px;">
                    <label for="mstatus" class="form-label">Marital Status</label>
                </div>    
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="inlineRadioOptions2" id="inlineRadio7" value="Single">
                        <label class="form-check-label" for="inlineRadio1">Single</label>
                      </div>
                      <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="inlineRadioOptions2" id="inlineRadio8" value="Married">
                        <label class="form-check-label" for="inlineRadio2">Married</label>
                      </div>
                    <div style="margin-top:15px;">
                        <label for="aadhar" class="form-label">Aadhar Number</label>
                        <input type="number" class="form-control" style="width:500px;" id="aadhar" name="aadhar">
                    </div>
                    <div style="margin-top:15px;">
                        <label for="add" class="form-label">Communal Address</label>
                        <input type="text" class="form-control" style="width:500px;" placeholder="Street Address line 1" name="st1" id="st1">
                        <input type="text" class="form-control" style="width:500px;margin-top:10px;" placeholder="Street Address line 1" name="st2" id="st2">
                        <div class="row" style="margin-top:10px;width:525px;">
                            <div class="col">
                              <input type="text" class="form-control" placeholder="City" name="city" id="city">
                            </div>
                            <div class="col">
                              <input type="text" class="form-control" placeholder="State" name="state" id="state">
                            </div>
                          </div>
                          <div class="row" style="margin-top:10px;width:525px;">
                            <div class="col">
                              <input type="number" class="form-control" placeholder="Zip Code" name="zip" id="zip">
                            </div>
                            <div class="col">
                              <input type="text" class="form-control" placeholder="Country" name="country" id="country">
                            </div>
                          </div>
                    </div>
                            <div style="margin-top:20px;text-align: center;">
                            <button class="btn btn-outline-primary" style="width:600px;" name="signup" type="submit">Signup</button>
                        </div>
                        </form>
              </p>
            </div>
          </div>
                <?php if(isset($_POST['signup'])){
                        $username = $_POST['username'];
                        $password = $_POST['password'];
                        $first = $_POST['first'];
                        $last =  $_POST['last'];
                        $dob = $_POST['dob'];
                        $ac = $_POST['ac'];
                        $email = $_POST['email1'].'@'.$_POST['email2'];
                        $mobile =  $_POST['mobile'];
                        $aadhar = $_POST['aadhar'];
                        $address = $_POST['st1'].",".$_POST['st2'].",".$_POST['city'].",".$_POST['state'].",". $_POST['zip'].",".$_POST['country'];
                        $marital = $_POST['inlineRadioOptions2'];
                        $gender = $_POST['inlineRadioOptions1'];
                        $title = $_POST['inlineRadioOptions'];

                        $end = "SELECT User_ID from user_details WHERE Mobile_Number = '$mobile'";
                        $end1 = $con->query($end);
                        $num = $end1->num_rows;
                        $query = "SELECT User_ID from user_details WHERE Email_ID = '$email'";
                        $result = $con->query($query);
                        $num2 = $result->num_rows;
                        $query = "SELECT User_ID from user_details WHERE Aadhar_Number = '$aadhar'";
                        $result = $con->query($query);
                        $num3 = $result->num_rows;
                        $query = "SELECT User_ID from user_details WHERE Username = '$username'";
                        $result = $con->query($query);
                        $num4 = $result->num_rows;
                        if($num == 0 && $num2 == 0 && $num3 == 0 && $num4 == 0){
                          $query2 = "INSERT INTO user_details (First_Name,Last_Name,Aadhar_Number,Date_of_Birth,Mobile_Number,Email_ID,Title,Username,Password,Gender,Address,Marital_Status) 
                          values ('$first','$last','$aadhar','$dob','$mobile','$email','$title','$username','$password','$gender','$address','$marital')";
                          $result2 = $con->query($query2);
                          $query3 = "SELECT * FROM user_details WHERE First_Name = '$first' AND Last_Name = '$last' AND Aadhar_Number = '$aadhar'AND Date_of_Birth = '$dob'AND Mobile_Number = '$mobile' AND
                          Email_ID = '$email'AND Title = '$title' AND Username = '$username' AND Password = '$password' AND Gender = '$gender'AND Address = '$address' AND Marital_Status = '$marital'";
                          $result3 = $con->query($query3);
                          $num2 = $result3->num_rows;
                          if($num2>0){
                            echo "<script type = \"text/javascript\">
                            window.location = (\"login.php\")
                            </script>";
                          }  
                        }
                        else{
                          if($num > 0){
                            echo "<div class='alert alert-danger' role='alert'>
                            Mobile Number already in use!
                            </div>";
                          }
                          elseif($num2 > 0){
                            echo "<div class='alert alert-danger' role='alert'>
                            Email already in use!
                            </div>";
                          }
                          elseif($num3 > 0){
                            echo "<div class='alert alert-danger' role='alert'>
                            Aadhar Number already in use!
                            </div>";
                          }
                          elseif($num4 > 0){
                            echo "<div class='alert alert-danger' role='alert'>
                            Username already in use!
                            </div>";
                          }
                        }
                    }
                ?>
            </div>
        </div>
        
    </body>
</html> 

