<?php
include "dbcon.php";
session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<title>Forgot Password</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-aFq/bzH65dt+w6FI2ooMVUpc+21e0SRygnTpmBvdBgSdnuTN7QbdgL+OapgHtvPp" crossorigin="anonymous">
</head>
<body style="background-color:#f8f9fc;">
<nav class="navbar navbar-dark bg-dark" style="height:70px;">
            <div class="container-fluid">
              <a href="login.php" type="button" class="btn btn-success">Back</a>
            </div>
        </nav>
<div class="card" style="width: 500px;height:420px;margin-left:30%;margin-top:70px;box-shadow: 10px 10px 5px lightgrey;">
            <div class="card-body">
				<form role="form" action="<?php echo $_SERVER['PHP_SELF']; ?>"method="POST" enctype="multipart/form-data">
                <h5 class="card-title" align="center" style="font-size:30px">Forgot Password</h5>
                <p class="card-text"><div style="margin-top:40px;">
				<div style="margin-top:20px;">
				<div style="margin-top:15px;">
                    <label for="username" class="form-label">Username</label>
                    <input type="password" class="form-control" name="username" placeholder="username">
                </div> 
				<div style="margin-top:20px;">
                    <label for="email">Email</label>
                    <input type="email" class="form-control" id="email" name="email" placeholder="example@gmail.com" maxlength="50">
				</div>
				<div style="margin-top:30px;">
					<button type="submit" name="sendmail" style="min-width:465px;" class="btn btn-md btn-outline-primary btn-block">Send</button>
				</div>
				</form>	
	<?php 
		if(isset($_POST['sendmail'])) {
			require 'assets/PHPMailerAutoload.php';
			require 'credential.php';
			$username = $_POST['username'];
			$empid = $_POST['password'];
				$query = "SELECT Password FROM user_details WHERE username = '$username'";
				$result = $con->query($query);
				$final = $result->fetch_assoc();
			$mail = new PHPMailer;                    
			$mail->isSMTP();                                      
			$mail->Host = 'smtp.gmail.com';  
			$mail->SMTPAuth = true;                              
			$mail->Username = EMAIL;                 
			$mail->Password = PASS;                         
			$mail->SMTPSecure = 'tls';                            
			$mail->Port = 587; 
			$mail->SMTPKeepAlive = true;   
			$mail->setFrom(EMAIL, 'GlobeTrotter');
			$mail->addAddress($_POST['email']); 

			$mail->addReplyTo(EMAIL);
			$mail->isHTML(true);                                  
			$query = $_POST['query'];
			$mail->Subject = 'Encrypted Password';
			$mail->Body    = "Your password is" . '&nbsp;' . $final['Password'];
			if(!$mail->send()) {
			    echo 'Message could not be sent.';
			    echo 'Mailer Error: ' . $mail->ErrorInfo;
			} else {
			    echo "<div class='alert alert-success' role='alert' style='margin-top:6px;' align='center'>
							Mail has been sent!
    					</div>";
			}
		
	}
	 ?>
</body>
</html>
